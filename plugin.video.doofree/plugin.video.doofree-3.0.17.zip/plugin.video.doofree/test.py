import urllib2

headers = {}
headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'
#headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
#headers['Upgrade-Insecure-Requests'] = 1
request = urllib2.Request('http://ipv6.icefilms.info/tv/a-z/B', headers=headers)

response = urllib2.urlopen(request, timeout=5)
result = response.read()
print result