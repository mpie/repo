# -*- coding: utf-8 -*-

'''
    DooFree Add-on
    Copyright (C) 2015 Mpie
'''

import xbmc
xbmc.executebuiltin('RunPlugin(plugin://plugin.video.doofree2/?action=service)')
